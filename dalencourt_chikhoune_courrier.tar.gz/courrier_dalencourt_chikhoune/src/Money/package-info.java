/**
 * 
 */
/**
 * Package which manage the money part of the program
 * 
 * @author Alex Dalencourt
 * @author Sellenia Chikhoune
 *
 */
package Money;