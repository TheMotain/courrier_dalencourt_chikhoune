/**
 * 
 */
/**
 * Package tests for money
 * 
 * @author Alex Dalencourt
 * @author Sellenia Chikhoune
 *
 */
package TestMoney;