/**
 * 
 */
/**
 * Contains all classes which describe a city
 * 
 * @author Alex Dalencourt
 * @author Sellenia Chikhoune
 *
 */
package City;