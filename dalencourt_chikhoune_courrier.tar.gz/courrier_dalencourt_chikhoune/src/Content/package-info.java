/**
 * 
 */
/**
 * Package for the content of letters
 * 
 * @author Alex Dalencourt
 * @author Sellenia Chikhoune
 *
 */
package Content;