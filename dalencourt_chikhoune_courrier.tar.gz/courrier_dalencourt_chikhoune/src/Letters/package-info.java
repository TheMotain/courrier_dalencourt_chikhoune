/**
 * 
 */
/**
 * Contains all classes which describe a letter
 * 
 * @author Alex Dalencourt
 * @author Sellenia Chikhoune
 *
 */
package Letters;