/**
 * 
 */
package TestContent;

import org.junit.Test;

/**
 * Test of the Content class
 * 
 * @author Alex Dalencourt
 * @author Sellenia Chikhoune
 * 
 */
public interface TestContent {

	@Test
	public void test_getDescription();
}
