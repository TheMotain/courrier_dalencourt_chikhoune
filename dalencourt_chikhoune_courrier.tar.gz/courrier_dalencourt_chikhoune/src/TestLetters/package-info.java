/**
 * 
 */
/**
 * Package test for letters
 * 
 * @author Alex Dalencourt
 * @author Sellenia Chikhoune
 *
 */
package TestLetters;